const calculateTemp=()=>{
    const numberTemp=document.getElementById('temp').ariaValueMax;
    //console.log(numberTemp);
    const tempSelected =document.getElementById('temp-diff');
    const valueTemp=temp-diff.options[tempSelected.selectedIndex].value;
    const calToFah=(cel)=>{
        let fahrenheit= Math.round((cel*9/5) +32);
        return fahrenheit;
    }
    const fahToCal=(fehr)=>{
        let celsius= Math.round((fehr - 32) *5/9);
        return celsius;
    }
    let result;
    if(valueTemp=='cel'){
        result =celToFah(numberTemp);
        document.getElementById('resultContainerr').innerHTML='=${result}°fahrenheit';
    }else{
        result =fahToCel(numberTemp);
        document.getElementById('resultContainerr').innerHTML='=${result}°celsius';
    }
}
